import{S as e,i as t,s as n}from"../chunks/vendor-c55a0f62.js";class l extends e{constructor(s){super();t(this,s,null,null,n,{})}}export{l as default};
