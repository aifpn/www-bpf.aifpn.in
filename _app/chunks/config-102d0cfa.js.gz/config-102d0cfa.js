const s=!1,e={is_dev:s,base_url:"https://bpf.aifpn.in"};export{e as c};
