import{r}from"./singletons-a42a5e91.js";const n=r,a=s;async function s(o,t){return n.goto(o,t,[])}export{a as g};
